/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocine.coneccionBD;

import com.mycompany.proyectocine.model.PeliculaDAO;
import com.mycompany.proyectocine.model.PeliculaDTO;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;


/**
 *
 * @author Gisselle
 */
public class PeliculaController {
    
    

    public ArrayList<PeliculaDAO> buscarPeliculaAllController(Connection conexion) throws SQLException{
        PeliculaDTO pelicula = new PeliculaDTO();
        
        return pelicula.buscarPeliculaAll(conexion);
    }

    public boolean agregarPeliculaController(PeliculaDAO peliNueva, Connection conn) throws SQLException {
        PeliculaDTO pelicula = new PeliculaDTO();
        pelicula.agregarPelicula(peliNueva, conn);
        return true;
    }
    
    
    public boolean modificarPeliculaIdController(PeliculaDAO peliculaBuscar, Connection conexion) throws SQLException{
        PeliculaDTO pelicula = new PeliculaDTO();
        
        pelicula.modificarPeliculaID(peliculaBuscar, conexion);
        return true;
    }

    public boolean buscarPeliculaIdController(PeliculaDAO buscarPelicula, Connection conn) throws SQLException{
        PeliculaDTO pelicula = new PeliculaDTO();
        
        return pelicula.buscarPeliculaId(buscarPelicula, conn);
    
    }

    public boolean eliminarPeliculaIdController(PeliculaDAO peliculaEliminar, Connection conn)throws SQLException{
        PeliculaDTO pelicula = new PeliculaDTO();
        
        pelicula.eliminarPeliculaXId(peliculaEliminar, conn);
        return true;
    }
    
    /**public void eliminarPeliculaIdController(int id, Connection conexion) throws SQLException {
        PeliculaDAO peliculaDAO = new PeliculaDAO();
        peliculaDAO.eliminarPeliculaPorId(id);
    }*/

    // ...
    
}
