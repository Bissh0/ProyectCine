/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectocine;


import com.mycompany.proyectocine.view.FramePrincipal;
import java.sql.SQLException;

/**
 *
 * @author Gisselle
 */
public class ProyectoCine {

    public static void main(String[] args) throws SQLException {
        
        FramePrincipal framePrincipal = new FramePrincipal();
        framePrincipal.setVisible(true);
        
       
    }
}
