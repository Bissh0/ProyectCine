/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocine.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Gisselle
 */
public class PeliculaDTO {
    
    
    //Inserta los cositos en la BD
    public boolean agregarPelicula (PeliculaDAO peliculaNueva, Connection conexion)throws SQLException {
        String queryStatement = "INSERT INTO GALIAGA.PELICULA (ID_PELICULA, NOMBRE_PELICULA, DIRECTOR_PELICULA, GENERO_PELICULA, DURACION_PELICULA, ANNO_PELICULA) VALUES (?,?,?,?,?,?)";
        System.out.println("\n Query is: " + queryStatement);
        PreparedStatement ps = conexion.prepareStatement(queryStatement);
        
        //con el ps.set se asignan valores a los ?
        ps.setInt(1,peliculaNueva.getId());
        ps.setString(2, peliculaNueva.getNombre());
        ps.setString(3, peliculaNueva.getDirector());
        ps.setString(4, peliculaNueva.getGenero());
        ps.setInt(5,peliculaNueva.getDuracion());
        ps.setInt(6, peliculaNueva.getAnno());
        
        int resultado = ps.executeUpdate();
        System.out.println("Catidad insertados: " + resultado);
        return true;
    }
    
    //MODIFICA POR ID
    public boolean modificarPeliculaID(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException{
        String queryStatement = "UPDATE " + conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE ID_PELICULA=?";
        System.out.println("\n Query is: " + queryStatement);
        PreparedStatement ps = conexion.prepareStatement(queryStatement);
        
        ps.setInt(1,peliculaNueva.getId());
        ps.setString(2, peliculaNueva.getNombre());
        ps.setString(3,peliculaNueva.getDirector());
        ps.setString(4, peliculaNueva.getGenero());
        ps.setInt(5, peliculaNueva.getDuracion());
        ps.setInt(6,peliculaNueva.getAnno());
        ps.setInt(7,peliculaNueva.getId());
        
        
        int resultado = ps.executeUpdate();
        System.out.println("Cantidad modificados: "+resultado);
        return true;
    }
    
    //MODIFICA POR NOMBRE
    public boolean modificarPeliculaNombre(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException{
        String queryStatement = "UPDATE "+conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE NOMBRE_PELICULA=?";
        System.out.println("\n Query is: "+queryStatement);
        PreparedStatement ps = conexion.prepareStatement(queryStatement);
        
        ps.setInt(1,peliculaNueva.getId());
        ps.setString(2, peliculaNueva.getNombre());
        ps.setString(3,peliculaNueva.getDirector());
        ps.setString(4, peliculaNueva.getGenero());
        ps.setInt(5, peliculaNueva.getDuracion());
        ps.setInt(6,peliculaNueva.getAnno());
        ps.setString(7,peliculaNueva.getNombre());
        
        int resultado = ps.executeUpdate();
        System.out.println("Cantidad modificados: "+resultado);
        return true;
        
    }//el que se modifica se agrega al final? - si se agrega al final segun internet :3
    
    //MODIFICA POR DIRECTOR
    public boolean modificarPeliculaDirector(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException {
    String queryStatement = "UPDATE " + conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE DIRECTOR_PELICULA=?";
    System.out.println("\n Query is: " + queryStatement);
    PreparedStatement ps = conexion.prepareStatement(queryStatement);
    
    ps.setInt(1,peliculaNueva.getId());
    ps.setString(2, peliculaNueva.getNombre());
    ps.setString(3, peliculaNueva.getDirector());
    ps.setString(4, peliculaNueva.getGenero());
    ps.setInt(5, peliculaNueva.getDuracion());
    ps.setInt(6, peliculaNueva.getAnno());
    ps.setString(7, peliculaNueva.getDirector());
    
    int resultado = ps.executeUpdate();
    System.out.println("Cantidad modificados: " + resultado);
    return true;
    }
    
    //MODIFICA POR GENERO - NO CREO QUE FUNCIONE PQ ES UN COMBOBOX NO UN STRING NORMAL
    public boolean modificarPeliculaGenero(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException {
    String queryStatement = "UPDATE " + conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE GENERO_PELICULA=?";
    System.out.println("\n Query is: " + queryStatement);
    PreparedStatement ps = conexion.prepareStatement(queryStatement);
    
    ps.setInt(1,peliculaNueva.getId());
    ps.setString(2, peliculaNueva.getNombre());
    ps.setString(3, peliculaNueva.getDirector());
    ps.setString(4, peliculaNueva.getGenero());
    ps.setInt(5, peliculaNueva.getDuracion());
    ps.setInt(6, peliculaNueva.getAnno());
    ps.setString(7, peliculaNueva.getGenero());
    
    int resultado = ps.executeUpdate();
    System.out.println("Cantidad modificados: " + resultado);
    return true;
    }

    //MODIFICA POR DURACION
    public boolean modificarPeliculaDuracion(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException {
    String queryStatement = "UPDATE " + conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE DURACION_PELICULA=?";
    System.out.println("\n Query is: " + queryStatement);
    PreparedStatement ps = conexion.prepareStatement(queryStatement);
    
    ps.setInt(1,peliculaNueva.getId());
    ps.setString(2, peliculaNueva.getNombre());
    ps.setString(3, peliculaNueva.getDirector());
    ps.setString(4, peliculaNueva.getGenero());
    ps.setInt(5, peliculaNueva.getDuracion());
    ps.setInt(6,peliculaNueva.getAnno());
    ps.setInt(7, peliculaNueva.getDuracion());
    
    int resultado = ps.executeUpdate();
    System.out.println("Cantidad modificados: " + resultado);
    return true;
    }
    
    //MODIFICA POR AÑO
    public boolean modificarPeliculaAnno(PeliculaDAO peliculaNueva, Connection conexion) throws SQLException {
    String queryStatement = "UPDATE " + conexion.getSchema() + ".PELICULA SET ID_PELICULA=?, NOMBRE_PELICULA=?, DIRECTOR_PELICULA=?, GENERO_PELICULA=?, DURACION_PELICULA=?, ANNO_PELICULA=? WHERE ANNO_PELICULA=?";
    System.out.println("\n Query is: " + queryStatement);
    PreparedStatement ps = conexion.prepareStatement(queryStatement);
    
    ps.setInt(1,peliculaNueva.getId());
    ps.setString(2, peliculaNueva.getNombre());
    ps.setString(3, peliculaNueva.getDirector());
    ps.setString(4, peliculaNueva.getGenero());
    ps.setInt(5, peliculaNueva.getDuracion());
    ps.setInt(6, peliculaNueva.getAnno());
    ps.setInt(7, peliculaNueva.getAnno());
    
    int resultado = ps.executeUpdate();
    System.out.println("Cantidad modificados: " + resultado);
    return true;
    }
    
    
    //BUSCA TODAS LAS PELICULAS
    public ArrayList<PeliculaDAO> buscarPeliculaAll(Connection conexion) throws SQLException{
        String query = "SELECT ID_PELICULA, NOMBRE_PELICULA, DIRECTOR_PELICULA, GENERO_PELICULA, DURACION_PELICULA, ANNO_PELICULA FROM "+ conexion.getSchema()+".PELICULA";
        
        System.out.println("\nQuery is: "+query);
        
        PreparedStatement ps = conexion.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        
        ArrayList<PeliculaDAO> listaPelicula = new ArrayList<PeliculaDAO>();
        
        while(rs.next()){
            PeliculaDAO peliculaNueva = new PeliculaDAO();
            
            peliculaNueva.setId(rs.getInt(1));
            peliculaNueva.setNombre(rs.getString(2));
            peliculaNueva.setDirector(rs.getString(3));
            peliculaNueva.setGenero(rs.getString(4));
            peliculaNueva.setDuracion(rs.getInt(5));
            peliculaNueva.setAnno(rs.getInt(6));
            
            listaPelicula.add(peliculaNueva);
            
        }
        
        return listaPelicula;
    }

    public boolean buscarPeliculaId(PeliculaDAO buscarPelicula, Connection conexion)throws SQLException {
        String query = "SELECT ID_PELICULA, NOMBRE_PELICULA, DIRECTOR_PELICULA, GENERO_PELICULA, DURACION_PELICULA, ANNO_PELICULA FROM "+ conexion.getSchema()+".PELICULA WHERE ID_PELICULA=?";
        System.out.println("\nQuery is: "+query);
        
        PreparedStatement ps = conexion.prepareStatement(query);
        ps.setInt(1, buscarPelicula.getId());
        
        ResultSet rs = ps.executeQuery();
        
        if(rs.next()){
            buscarPelicula.setNombre(rs.getString(2));
            buscarPelicula.setDirector(rs.getString(3));
            buscarPelicula.setGenero(rs.getString(4));
            buscarPelicula.setDuracion(rs.getInt(5));
            buscarPelicula.setAnno(rs.getInt(6));
            return true;
        }else{
            return false;
        }
    }
    
    
    public boolean eliminarPeliculaXId(PeliculaDAO eliminarPelicula, Connection conexion)throws SQLException{
        String query = "DELETE FROM "+ conexion.getSchema()+".PELICULA WHERE ID_PELICULA =?";
        
        System.out.println("\nQuery is: "+query);
        
        PreparedStatement ps = conexion.prepareStatement(query);
        ps.setInt(1, eliminarPelicula.getId());
        
        int filasEliminadas = ps.executeUpdate();
        
        return filasEliminadas > 0;
    }
}
    /*String query = "DELETE FROM " + conexion.getSchema() + ".PELICULA WHERE ID_PELICULA = ?";
    
    System.out.println("\nQuery is: " + query);
    
    PreparedStatement ps = conexion.prepareStatement(query);
    ps.setInt(1, idPelicula); // Establece el valor del ID a eliminar
    
    int filasAfectadas = ps.executeUpdate();
    
    return filasAfectadas > 0; // Devuelve true si al menos una fila fue eliminada*/